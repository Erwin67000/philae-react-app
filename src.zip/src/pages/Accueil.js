import React from 'react';

const Accueil = () => {
    return (
        <main>
            <h1>Bienvenue sur le nouveau site web de Philae Design</h1>
            <p>Site en constuction.</p>
            {/* Ajoute des images ou teasers ici */}
        </main>
    );
};

export default Accueil;